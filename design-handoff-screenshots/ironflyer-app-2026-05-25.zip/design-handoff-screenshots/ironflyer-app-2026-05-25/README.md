# Ironflyer App Screenshots - Design Handoff

Created: 2026-05-25

This folder contains full-page screenshots for designer handoff.

- `desktop-1440/`: 17 desktop screenshots at 1440x1100 viewport
- `mobile-390/`: 17 mobile screenshots at 390x844 viewport
- `index.html`: visual contact sheet for quick review
- `manifest.json`: route and file mapping

Open `index.html` to review all screens in one place.
